(function(){
  // Mobile menu
  const toggle = document.querySelector('[data-mobile-toggle]');
  const menu = document.querySelector('[data-mobile-menu]');
  if(toggle && menu){
    toggle.addEventListener('click', () => {
      const open = menu.style.display === 'block';
      menu.style.display = open ? 'none' : 'block';
      toggle.setAttribute('aria-expanded', String(!open));
    });
  }

  // FAQ accordion
  const items = document.querySelectorAll('.faq-item');
  items.forEach(item => {
    const q = item.querySelector('.faq-q');
    if(!q) return;
    q.addEventListener('click', () => {
      const wasOpen = item.classList.contains('open');
      items.forEach(i => i.classList.remove('open'));
      if(!wasOpen) item.classList.add('open');
    });
  });

  // Smooth scroll for in-page anchors with sticky offset
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href');
      if(!id || id === '#') return;
      const el = document.querySelector(id);
      if(!el) return;
      e.preventDefault();
      const top = el.getBoundingClientRect().top + window.scrollY - 84;
      window.scrollTo({ top, behavior: 'smooth' });
      if(menu) menu.style.display = 'none';
    });
  });

  // Pricing buttons: allow user to wire Stripe links later
  document.querySelectorAll('[data-stripe-link]').forEach(btn => {
    btn.addEventListener('click', () => {
      const url = btn.getAttribute('data-stripe-link');
      if(url && url.startsWith('https://')){
        window.location.href = url;
      } else {
        // Fallback: highlight that link needs to be configured
        btn.textContent = 'Add Stripe Checkout Link';
        btn.style.opacity = '0.85';
      }
    });
  });
})();
